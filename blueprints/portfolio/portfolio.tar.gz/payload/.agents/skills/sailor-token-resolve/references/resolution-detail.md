# Resolution detail — output contract, mechanics, DEX classification

Consult this only when you need the JSON schema or a deeper "how/why". The
actionable flow lives in `SKILL.md`; this is progressive disclosure.

## Output shapes (pick the right consumer)

| Invocation | stdout shape |
|---|---|
| 1 symbol, single configured chain / `--chain` | **bare object** — `{address, decimals, feeTier, swapReady, quote, venues[], …}` (the shape `sailor-swap-quote` / `sailor-templates` (swap) expect) |
| 1 symbol, ≥2 configured chains | **array** of bare objects (one per chain) |
| ≥2 symbols | **portfolio**: `{ tokens: [tokenWrapper…], summary }` |
| 1 symbol + `--json`/`--all-chains` | **token wrapper** (see below) |

A **token wrapper** is:

```jsonc
{
  "query": "UNI",
  "chains": {                       // keyed by chain name; each value is a bare per-chain object
    "base":     { "address": "0x…", "decimals": 18, "swapReady": true, "feeTier": 10000,
                  "venues": [ … ], "bestVenue": { … }, "onchainVerified": true, … },
    "unichain": { … }
  },
  "chainsWithLiquidity": ["unichain","base","arbitrum"],
  "onSailChain": true,
  "crossChain": { "action": "route", "deepestChain": "base", "note": "…human guidance…" }
}
```

A **venue** (inside `venues[]`, sorted deepest-first, capped at 8; `venuesTotal` is the full
count) is:

```jsonc
{ "protocol": "uniswap-v3",      // uniswap-v3 | uniswap-v4 | uniswap-v2 | sushiswap | pancakeswap | aerodrome | other
  "dexId": "uniswap",            // raw source id (DexScreener: "uniswap"/"aerodrome"…; GeckoTerminal: "uniswap-v3-base")
  "pool": "0x…", "feeTier": 500, // basis points (500 = 0.05%); null if the pool has no fee in its name
  "pairedSymbol": "USDC", "pairedToken": "0x…",
  "liquidityUsd": 8645941, "volume24hUsd": 22333927,
  "sailRoutable": true,          // Sail's fast path can route it (see below)
  "quoteVerified": true }        // a live on-chain QuoterV2 quote confirmed THIS venue
```

## How it works

1. **Symbol → address** (two layers): curated registry (instant, offline) → **DexScreener**
   search (keyless, primary), then GeckoTerminal search (keyless fallback) for anything not
   curated. Candidates are ranked by **real 24h volume first, then liquidity** — a planted
   look-alike that shares the symbol but trades nothing never wins over the real token (the
   ZAMA fix). The on-chain `symbol()` check is the final authority (a wrong DEX-side match is
   rejected, not trusted).
2. **On-chain verify** — `symbol()` + `decimals()` via eth_call on every chain that has an RPC.
   This is the source of truth (`decimalsSource: "onchain"`). On an `--all-chains` scan of a chain
   with no RPC, metadata falls back to the DEX feed (`decimalsSource: "dexscreener-unverified"`
   or `"geckoterminal-unverified"`) — flag this to the user before wiring it into a mandate.
3. **Liquidity venue map** — DexScreener's keyless pair endpoints (primary, ~300 req/min, flat
   response) return every tracked pool across **all DEXes** (Uniswap V3/V4, Sushiswap, PancakeSwap,
   Aerodrome, …), with protocol, pool address, fee tier and USD depth. GeckoTerminal
   (`/networks/{net}/tokens/{addr}/pools`, ~10–30 req/min) is the deep-coverage fallback when
   DexScreener has no venues. One lookup per token per chain, cached + throttled.
4. **Swap-readiness (on-chain confirmed)** — quotes USDC→token across fee tiers 500/3000/10000
   via Uniswap V3 QuoterV2 and marks the matching venue `quoteVerified: true`. This is the only
   *executable* signal; everything else in `venues[]` is informational.

## `sailRoutable` — what the swap template can actually route

Sail's shared `SwapPermission` takes an arbitrary `routers[]` allowlist plus token allowlists and a
slippage band against a Chainlink oracle, so it is **DEX-agnostic**. A venue is `sailRoutable: true`
when its router is one the template can be configured to call: **Uniswap V2/V3**, **SushiSwap**,
**PancakeSwap**, **Aerodrome**, **Velodrome**, and **Uniswap V4** (Unichain only). A DEX the resolver
doesn't classify (Curve, Balancer, bespoke routers) is surfaced but not routable — it needs a custom
mandate. (Pools with absurd fees — >10% — are spam and are never marked routable.)

One tier stays Uniswap-V3-specific: `quoteVerified` (a live on-chain QuoterV2 quote). That's the only
venue the resolver live-probes; every other routable venue is feed-reported (`quoteVerified: false`)
until an RPC is configured. So **"routable" = can the template swap here**, while **"quoteVerified" =
did we confirm it on-chain**. Use `swapReady` + `chainsWithLiquidity` for chain selection; use
`bestVenue.protocol` + `quoteVerified` to know *which* DEX to route through.

Two caveats for the safe (oracle) template: it needs a **Chainlink feed** for the token pair (tokens
without one use the weaker no-oracle variant), and non-Uniswap routers use a slightly different swap
call — so quoting/executing against Aerodrome/PancakeSwap/SushiSwap needs a per-DEX adapter in the
agent runtime, not just a new router address.

## Liquidity map (offline cache — read it, don't scan live)

`scripts/liquidity-map.json` is an offline cache of the top assets: for each, the
**Uniswap-list-sourced** canonical contract address + whether a Sail-routable USDC pool exists + its
depth + `volume24hUsd` + the DEX family (`dex`), per chain. The resolver reads it **first** and
skips the live feed scan for anything it answers, so a portfolio of major assets resolves in ~1–2
seconds instead of a live 10-chain scan.

**Identity is never guessed.** The map's address comes from the **Uniswap default token list**
(`https://tokens.uniswap.org`, a curated catalog of real contracts — via `build-top-assets-seed.mjs`),
never from a DexScreener search — asking DexScreener "what is the deepest pool called X?" is how a
planted look-alike (copied ticker, fake liquidity, zero volume) becomes the canonical address. The
resolver additionally trusts a map entry only when it **actually trades** (`volume24hUsd > 0`); a
zero-volume entry is rejected and falls through to the live volume-ranked search. So the map can
only ever fill a gap with a verified, trading address — never override or invent one.

- **Don't load the map into context** — it's ~230KB. Have `resolve-token.mjs` query it; that's its
  whole job. The agent never reads the file directly.
- **Refresh offline, in two steps.** `node scripts/build-top-assets-seed.mjs` reads the Uniswap
  token list (keyless, one static fetch, no API key) and writes per-chain addresses to
  `top-assets-seed.json`; then `node scripts/build-liquidity-map.mjs --seed top-assets-seed.json`
  rebuilds the map from that trusted seed + a DexScreener routable/volume check (keyless). The
  runtime never calls either source — both are team-run on a schedule. A map over 30 days old
  prints a refresh note.
- **It only covers its listed tokens.** The long tail still resolves live — slower but correct.
  The list carries ~690 symbols across 8 of the 10 Sail mainnets (hyperevm and megaeth resolve
  live). Re-run the seed to pick up newly listed tokens.

## Worked example — "create a DCA strategy of USDC, UNI, HYPE and MORPHO"

```bash
node scripts/resolve-token.mjs USDC UNI HYPE MORPHO --all-chains
```

A typical read of the result:
- **USDC** — the quote asset; swap-ready everywhere (`feeTier: null`, it *is* USDC).
- **UNI** — `route`; routable on Unichain/Base/Arbitrum. Pick by depth or by where the basket
  concentrates.
- **HYPE** — `route` only on **Unichain** (a real ~$4M Uniswap V3 USDC pool); absent/illiquid
  elsewhere. Tell the user HYPE is a Unichain-only leg here.
- **MORPHO** — `route` on **Base** (Uniswap V3 USDC pool); on other chains it exists but has no
  routable USDC pool. If the project is configured for Base, good; if not, `suggest-sma`.

Then, for each `route`/chosen-chain leg, hand `(address, decimals, feeTier)` to
`sailor-swap-quote` → `sailor-templates` (swap).

## Full pitfalls list (the long tail)

- **`getPool` is unreliable** on some forks — swap-readiness trusts a non-zero QuoterV2 quote,
  never the V3 factory's `getPool`.
- **Symbol ambiguity / scam collisions.** When a symbol isn't curated, the deepest-pool
  candidate whose on-chain `symbol()` matches is used. A scam token can share a real symbol; the
  liquidity ranking favours the canonical one, but for an obscure symbol glance at the resolved
  `address` and `source` before wiring it in — or pass the intended contract's `0x` address
  directly (address-input bypasses the DEX lookup). Also sanity-check a venue's `volume24hUsd`
  against its `liquidityUsd`: a huge pool with near-zero volume is inflated/non-trading, and a
  big pool whose `pairedSymbol` is a look-alike (e.g. a "HYPE/BASEDHYPE" pool) is a *different*
  asset — depth there does not make *your* token swap-ready.
- **Missing venues ≠ no liquidity.** A chain can be `swapReady: true` (from the on-chain
  QuoterV2 probe) yet show empty `venues[]` with `venuesError` set if the liquidity feed
  rate-limited that call. Trust `swapReady`; to repopulate the venue map for one chain, re-run
  `node scripts/resolve-token.mjs <SYM> --chain <name> --json`.
- **Rate limits and the timeout** — DexScreener (primary) is keyless at ~300 req/min and is
  throttled + cached; GeckoTerminal (fallback) is keyless but ~10–30 req/min. The script throttles
  and caches both, and widens the gap between calls adaptively when it hits a 429 (`DEX_MIN_SPACING_MS`
  / `GECKO_MIN_SPACING_MS` are the floors, the `*_MAX_SPACING_MS` values the caps). A big
  `--all-chains` portfolio prints a progress line per token as it goes, and a hard deadline
  (`RESOLVE_TIMEOUT_MS`, default 180s) returns whatever mapped so far with a `summary.timedOut` flag
  and `summary.unresolved` list rather than hanging — re-run only the unresolved tokens with a
  targeted `--chain`. A transient provider failure on one chain sets `venuesError` and leaves
  `swapReady` intact (it's from the on-chain probe) — it never aborts the whole run.
